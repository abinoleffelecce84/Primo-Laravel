<!DOCTYPE html>
<html>

	<head>
		<link href="css/index.css" rel="stylesheet" type="text/css">
		<link href="css/welc_logged.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
		
		<title>Benvenuto</title>
	</head>

	<body>

		@if(Auth::user())
		<header>
			<nav class="navbar navbar-default navbar-fixed-top">
			    <div class="container">
			        <div class="navbar-header page-scroll">
			            <div class="dropdown" id="miodrop">
			                <button onclick="myFunction()" class="dropbtn" id="user"> {{ Auth::user()->name }} <i class="fa fa-angle-down fa-lg"></i> 
			                </button>
			                <div id="myDropdown" class="dropdown-content">
			                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
			                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> {{ csrf_field() }} </form>
			                </div>
			            </div>
			        	<a class="navbar-brand" href="{{ route('start') }}" id="home">Home</a>
			        </div>
			    </div>
			    <div align="right">
		    		<a id="printbtn" class="btn btn-warning" href="{{ action('PasswordController@index', Auth::user()->id) }}">
		    			<button class="btn btn-danger" style="position: relative; left: 20px; top: 12px; background-color: transparent; margin-right: 40px; border-color: transparent; cursor: pointer; color: #00749F; "><i class="fa fa-cog fa-lg"></i></button>
	    			</a>
    			</div>
			</nav>
	    </header>

		<div id="center">
			<h1 align="center"><u>AG</u>enzia per l'<u>I</u>talia <u>D</u>igitale</h1>
			<br><br><br><br>
			<div id="foot" role="navigation">
				<span data-jibp="h" data-jiis="ic" id="xjs">
					<div id="navcnt" align="center">
						<?php

							$id1 = 1; $id2 = 2; $id3 = 3; $id4 = 4; $id5 = 5; $id8 = 8; $id10 = 10; $id13 = 13; $lev1 = "M"; 
							$lev2 = "S"; $lev3 = "A";

						?>

						<table class="table table-striped">
							<thead>
								<tr>
									<th>Livello</th>
									<th>Absc_Id</th>
								</tr>
							</thead>
							<tbody align="center">
								<tr>
									<td id="id" style="position: relative; ">
										<a href="{{ action('CrudsController@getLev',$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit" style="width: 80px;">Minimo</button>
										</a>&nbsp;
									</td>
									<td id="id">
										<a href="{{ action('CrudsController@getId_1M',$id1,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">1</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id2,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">2</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id3,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">3</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id4,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">4</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id5,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">5</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id8,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">8</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id10,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">10</button>
										</a>
										<a href="{{ action('CrudsController@getId_1M',$id13,$lev1) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">13</button>
										</a>
									</td>
								</tr>
								<tr>
									<td id="id">
										<a href="{{ action('CrudsController@getLev',$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit" style="width: 80px;">Standard</button>
										</a>&nbsp;
									</td>
									<td id="id">
										<a href="{{ action('CrudsController@getId_1S',$id1,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">1</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id2,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">2</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id3,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">3</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id4,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">4</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id5,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">5</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id8,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">8</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id10,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">10</button>
										</a>
										<a href="{{ action('CrudsController@getId_1S',$id13,$lev2) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">13</button>
										</a>
									</td>
								</tr>
								<tr>
									<td id="id">
										<a href="{{ action('CrudsController@getLev',$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit" style="width: 80px;">Alto</button>
										</a>&nbsp;
									</td>
									<td id="id">
										<a href="{{ action('CrudsController@getId_1A',$id1,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">1</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id2,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">2</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id3,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">3</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id4,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">4</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id5,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">5</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id8,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">8</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id10,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">10</button>
										</a>
										<a href="{{ action('CrudsController@getId_1A',$id13,$lev3) }}" class="btn btn-warning">
											<button id="selezione" class="btn btn-danger" type="submit">13</button>
										</a>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</span>
			</div>
		</div>
		
		<br><br><br><br><br><br>

		<div align="right">
			<a id="printbtn" class="btn btn-warning" href="{{ action('FileController@getPdf') }}">
		    	<button class="btn btn-danger" style="position: relative; left: 20px; background-color: transparent; margin-right: 40px; border-color: transparent; cursor: pointer; color: #00749F; "><i class="fa fa-print fa-2x"></i></button>
	    	</a>
	    	
	    </div>

		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th></th>
						<th>ABSC_ID</th>
						<th></th>
						<th>Descrizione</th>
						<th>Implementazione</th>
						<th>Livello</th>
						<th>Link/Allegati</th>
						<th colspan="3" align="center" id="action">Azioni</th>
					</tr>
				</thead>
				<tbody>
					@foreach($cruds as $post)
					<tr>
						<td id="id">{{ $post['id_1'] }}</td>
						<td id="id">{{ $post['id_2'] }}</td>
						<td id="id">{{ $post['id_3'] }}</td>
						<td id="desc" align="justify" style="padding-left: 15px; padding-right: 15px; min-width: 150px;">{{ $post['description'] }}</td>
						<td id="impl" align="justify" style="width: 900px;">{{ $post['implementation'] }}</td>
						<td id="lev">{{ $post['level'] }}</td>
						<td id="link">
							<br>
							@foreach($files2 as $link2)
								@if($link2['id_crud'] == $post['id'])
								<div align="center">
									<a href="{{ action('FileController@getDownload',$link2['id']) }}" style="color: #00749F;">{{ $link2['name'] }}</a><br>
									&nbsp;{{ $link2['updated_at'] }}
									<br><br>
								</div>
								@endif
							@endforeach
							@foreach($links as $resource)
								@if($resource['id_crud'] == $post['id'])
								<div align="center">
									<a href="http:\\{{ $resource['link'] }}" onclick="window.open(this.href);return false" style="color: #00749F;">{{ $resource['name'] }}</a><br>
									<br><br>
								</div>
								@endif
							@endforeach
						</td>
						<td id="action">
							<br>
							<a href="{{ action('CrudsController@change',$post['id']) }}" class="btn btn-danger">
								<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-pencil fa-lg">&nbsp;&nbsp;</i>Modifica</button>
							</a>
							<br><br>
							<a href="{{ action('CrudsController@getIdDetail',$post['id']) }}" class="btn btn-danger">
								<button id="elimina" class="btn btn-danger" type="submit" style="width: 90px;"><i class="fa fa-trash fa-lg" style="position: relative; right: 2px;">&nbsp;&nbsp;</i>Elimina</button>
							</a>
							<br><br>
						</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<br><br><br>

		<br><br><br><br><br>
		@endif
		@if(Auth::guest())
			<br><br><br><br>
			<div align="center">
		    <a href="{{ URL('/') }}" class="btn btn-danger">
					<button id="btn_expire" ></button>
				</a>
			</div>
			<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		@endif
	</body>

	<script src="js/drdown.js"></script>
</html>