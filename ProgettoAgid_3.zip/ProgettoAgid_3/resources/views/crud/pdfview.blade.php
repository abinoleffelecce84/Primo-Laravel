<!DOCTYPE html>
<html>

	<head>
		<link href="css/index.css" rel="stylesheet" type="text/css">
	</head>

	<body>

		<h1 align="center"><u>AG</u>enzia per l'<u>I</u>talia <u>D</u>igitale</h1>

		<br><br><br><br><br><br>

		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr align="center">
						<th></th>
						<th>ABSC_ID</th>
						<th></th>
						<th>Descrizione</th>
						<th>Implementazione</th>
						<th>Livello</th>
						<th align="center">Link/Allegati</th>
					</tr>
				</thead>
				<tbody>
					@foreach($cruds as $post)
					<tr>
						<td id="id">{{ $post['id_1'] }}</td>
						<td id="id">{{ $post['id_2'] }}</td>
						<td id="id">{{ $post['id_3'] }}</td>
						<td id="desc" align="justify" style="padding-left: 15px; padding-right: 15px; min-width: 150px;">{{ $post['description'] }}</td>
						<td id="impl" align="justify">{{ $post['implementation'] }}</td>
						<td id="lev">{{ $post['level'] }}</td>
						<td id="link">
							<br>
							@foreach($files2 as $link2)
								@if($link2['id_crud'] == $post['id'])
								<div align="center">
									<a href="{{ action('FileController@getDownload',$link2['id']) }}" style="color: #00749F;">{{ $link2['name'] }}</a><br>
									&nbsp;{{ $link2['updated_at'] }}
									<br><br>
								</div>
								@endif
							@endforeach
							@foreach($links as $resource)
								@if($resource['id_crud'] == $post['id'])
								<div align="center">
									<a href="http:\\{{ $resource['link'] }}" onclick="window.open(this.href);return false" style="color: #00749F;">{{ $resource['name'] }}</a><br>
									<br><br>
								</div>
								@endif
							@endforeach
						</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<br><br><br>
		<div class="container" align="right">
			<p align="right" style="padding-right:10px;">IL RESPONSABILE DELLA SICUREZZA<br>
				BERNARDI PIERO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
				(Sottoscritto digitalmente ai sensi dell'art. 21<br>
				D.L.gs n 82/2005 e s.m.i.)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
		</div>
		<br><br><br><br><br>
			
	</body>

	<style type="text/css">
		
		body{
			position: relative;
			top: 50px;
			font-family: 'Raleway', sans-serif;
		}

	</style>

</html>