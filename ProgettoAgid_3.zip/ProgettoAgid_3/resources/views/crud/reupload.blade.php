<!DOCTYPE html>
<html>

	<head>
		<title>Upload</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/upload.css') }}">
	</head>

	<body>
		@if(Auth::user())
		<br><br><br><br>
		<p align="center">Qui puoi caricare una versione aggiornata del file <u><b>{{ $file->name }}</b></u>.</p>
		<br><br><br><br>
		<div class="container">
			<div class="row">
				<form align="center" action="{{ action('FileController@update',$id) }}" method="post" class="form-horizontal" enctype="multipart/form-data">
		            {{ csrf_field() }}
		            <div align="center" class="container">
		                <input type="file" name="file" required>
		                <input id="modifica" type="submit" class="btn btn-input" value="Carica">
		            </div>
		        </form>
		    </div>
		</div>

		<br><br><br><br><br>
		<a href="{{ action('CrudsController@index') }}" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit">Indietro</button>
		</a>
		@endif
		@if(Auth::guest())
			<br><br><br><br>
			<div align="center">
		    <a href="{{ URL('/') }}" class="btn btn-danger">
					<button id="btn_expire" ></button>
				</a>
			</div>
			<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		@endif
	</body>
</html>