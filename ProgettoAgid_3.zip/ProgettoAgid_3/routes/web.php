<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts/welcome');
})->name('start');

Auth::routes();

Route::get('configuration/{id}','PasswordController@index')->name('options');

Route::post('configuration/{id}/updated',['as'=>'changePassword','uses'=>'PasswordController@update']);

Route::get('cruds','CrudsController@index')->name('cruds');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/cruds/{id}',['as'=>'idDetail','uses'=>'CrudsController@getIdDetail']);

Route::get('/cruds/{id}/delete',['as'=>'idDelete','uses'=>'CrudsController@delete']);

Route::get('/cruds/{id}/change',['as'=>'idEdit','uses'=>'CrudsController@change']);

Route::get('/cruds/{id}/id_1M',['as'=>'idGet','uses'=>'CrudsController@getId_1M']);

Route::get('/cruds/{id}/id_1S',['as'=>'idGet','uses'=>'CrudsController@getId_1S']);

Route::get('/cruds/{id}/id_1A',['as'=>'idGet','uses'=>'CrudsController@getId_1A']);

Route::get('/cruds/{level}/level',['as'=>'level','uses'=>'CrudsController@getLev']);

Route::get('/file/{id}/upload',['as'=>'upload','uses'=>'FileController@reUpload']);

Route::get('showFile', ['as'=>'upload','uses'=>'FileController@showUploadForm']); // as == ({route})->name('');

Route::post('showFile/{id}',['uses'=>'FileController@storeFile']);

Route::resource('file','FileController');

Route::post('update/{id}',['uses'=>'FileController@update']);

Route::get('/showFile/{id}/delete',['as'=>'delete','uses'=>'FileController@delete']);

Route::get('/showFile/{id}/download',['as'=>'download','uses'=>'FileController@getDownload']);

Route::get('getpdf',['as'=>'getpdf','uses'=>'FileController@getPdf']);

Route::get('getpdf/{level}',['as'=>'getpdflevel','uses'=>'FileController@getPdfLevel']);

Route::get('create/{id}/link',['as'=>'link','uses'=>'LinkController@create']);

Route::get('create/{id}/delete',['as'=>'delete','uses'=>'LinkController@delete']);

Route::get('cruds/{id}/open',['as'=>'open','uses'=>'LinkController@open']);

Route::get('resource/{id}/edit',['as'=>'edit','uses'=>'LinkController@edit']);

Route::post('create/link/store/{link}',['as'=>'store','uses'=>'LinkController@store']);

Route::post('link/{id}',['uses'=>'LinkController@update']);