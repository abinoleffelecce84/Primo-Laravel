<!DOCTYPE html>
<html>

	<head>

		<link href="css/welc_logged.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	</head>

	<body>

		<header>
			<nav class="navbar navbar-default navbar-fixed-top">
			    <div class="container">
			        <div class="navbar-header page-scroll">
			            <div class="dropdown" id="miodrop">
			                <button onclick="myFunction()" class="dropbtn" id="user"> <?php echo e(Auth::user()->name); ?> <i class="fa fa-angle-down fa-lg"></i> 
			                </button>
			                <div id="myDropdown" class="dropdown-content">
			                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
			                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"> <?php echo e(csrf_field()); ?> </form>
			                </div>
			            </div>
			        	<a class="navbar-brand" href="<?php echo e(route('start')); ?>" id="home">Home</a>
			        </div>
			    </div>
			    <div align="right">
		    		<a id="printbtn" class="btn btn-warning" href="<?php echo e(action('PasswordController@index', Auth::user()->id)); ?>">
		    			<button class="btn btn-danger" style="position: relative; left: 20px; top: 12px; background-color: transparent; margin-right: 40px; border-color: transparent; cursor: pointer; color: #00749F; "><i class="fa fa-cog fa-lg"></i></button>
	    			</a>
    			</div>
			</nav>
	    </header>

	    <br><br><br>
	    <h1 align="center">Benvenuto, <?php echo e(Auth::user()->name); ?></h1>
	    <p align="center" id="subtext"><b>Clicca per accedere all'applicazione di tuo interesse</b></p>

	    <br><br><br>

	    <div align="center">
		    <a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-danger">
				<button id="btn_enter"></button>
			</a>
		</div>

	</body>
</html>