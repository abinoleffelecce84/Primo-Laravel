<!DOCTYPE html>
<html>

	<head>
		<title>Upload</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/upload.css')); ?>">
	</head>

	<body>

		<br><br><br><br>
		<p align="center">Qui puoi caricare una versione aggiornata del file <u><b><?php echo e($file->name); ?></b></u>.</p>
		<br><br><br><br>
		<div class="container">
			<div class="row">
				<form align="center" action="<?php echo e(action('FileController@update',$id)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		            <?php echo e(csrf_field()); ?>

		            <div align="center" class="container">
		                <input type="file" name="file" required>
		                <input id="modifica" type="submit" class="btn btn-input" value="Carica">
		            </div>
		        </form>
		    </div>
		</div>

		<br><br><br><br><br>
		<a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit">Indietro</button>
		</a>
	
	<style type="text/css">

	</style>

	</body>
</html>