<!DOCTYPE html>
<html>

	<head>
		<title>Upload</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/upload.css')); ?>">
	</head>

	<body>

		<header>
			<nav class="navbar navbar-default navbar-fixed-top">
			    <div class="container">
			        <div class="navbar-header page-scroll">
			            <div class="dropdown" id="miodrop">
			                <button onclick="myFunction()" class="dropbtn" id="user"> <?php echo e(Auth::user()->name); ?>

			                	<i class="fa fa-sort-desc" aria-hidden="true" style="position: relative; bottom: 3px;"></i>
			                </button>
			                <div id="myDropdown" class="dropdown-content">
			                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
			                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"> <?php echo e(csrf_field()); ?> </form>
			                </div>
			            </div>
			        	<a class="navbar-brand" href="<?php echo e(route('start')); ?>" id="home">Home</a>
			        </div>
			    </div>
			</nav>
	    </header>

		<p align="center">Qui puoi <u><b>aggiornare</b></u> i file già presenti con una nuova versione.</p>
		<br>

		<div class="container">
			<table class="table table-striped" align="center">
				<thead>
					<tr>
						<th>Nome</th>
						<th>Dimensioni(kb)</th>
						<th>Aggiornato il</th>
						<th style="padding-right: 20px;">Azioni</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($link['id']>1): ?>
					<tr>
						<td id="id"><?php echo e($link['name']); ?></td>
						<td id="id"><?php echo e($link['size']/1024); ?></td>
						<td id="id"><?php echo e($link['updated_at']); ?></td>
						<td>
							<a href="<?php echo e(action('FileController@reUpload',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
								<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-upload fa-lg">&nbsp;&nbsp;&nbsp;</i>Carica</button>
							</a>
							<a href="<?php echo e(action('FileController@getDownload',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
								<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-download fa-lg">&nbsp;&nbsp;&nbsp;</i>Scarica</button>
							</a>
							<a href="<?php echo e(action('FileController@delete',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
								<button id="elimina" class="btn btn-danger" type="submit"><i class="fa fa-trash fa-lg">&nbsp;&nbsp;&nbsp;</i>Elimina</button>
							</a>
						</td>
					</tr>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<br><br><br><br>
		<p align="center">Per caricare un <u><b>nuovo file</b></u>, utilizzare il form seguente.</p>
		<br><br>
		<div class="container">
			<div class="row">
				<form align="center" action="<?php echo e(route('upload')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		            <?php echo e(csrf_field()); ?>

		            <div align="center" class="container">
		                <input type="file" name="file" value="Sfoglia..." required>
		                <input id="elimina" type="submit" class="btn btn-input" value="Carica">
		            </div>
		        </form>
		    </div>
		</div>

		<br><br><br><br><br>
		<a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i> Indietro</button>
		</a>
		<br><br><br><br><br><br><br><br><br><br>

	<script type="text/javascript">
		
		function myFunction() {
    		document.getElementById("myDropdown").classList.toggle("show");
		}
		window.onclick = function(event) {
    		if (!event.target.matches('.dropbtn')) {

        		var dropdowns = document.getElementsByClassName("dropdown-content");
        		var i;
        		for (i = 0; i < dropdowns.length; i++) {
            		var openDropdown = dropdowns[i];
            		if (openDropdown.classList.contains('show')) {
                		openDropdown.classList.remove('show');
            		}
        		}
    		}
		}

	</script>

	</body>
</html>