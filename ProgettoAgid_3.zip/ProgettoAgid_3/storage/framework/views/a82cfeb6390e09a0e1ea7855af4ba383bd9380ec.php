<!DOCTYPE html>
<html>

	<head>
		<title>Modifica</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/edit.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/upload.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	</head>

	<body>
		<?php if(Auth::user()): ?>
		<br><br><br><br>
		<p align="center">Sicuro di voler procedere alla<b> modifica</b> del punto <b><?php echo e($crud->id_1); ?>.<?php echo e($crud->id_2); ?>.<?php echo e($crud->id_3); ?></b>? Premi "Modifica" per procedere, "Indietro" per annullare.</p>
		<br>
		<p align="center">Se presenti, <u><b>ricorda di aggiornare</b></u> anche i file e/o i link alle risorse.</p>
		<br><br><br><br>

		<div class="container" align="center">
			<form method="POST" action="<?php echo e(action('CrudsController@update',$id)); ?>">
			<?php echo e(csrf_field()); ?>

				<table class="table table-striped">
					<thead>
						<tr>
							<th>Descrizione</th>
							<th>Implementazione</th>
							<th>Livello</th>
							<th colspan="3" align="center">Azioni</th>
						</tr>
					</thead>
					<tbody>
						<tr align="center">
							<td>
								<input name="_method" type="hidden" value="PATCH">
								<div class="col-sm-10">
									<textarea name="description" rows="8" cols="70"><?php echo e($crud->description); ?></textarea>
								</div>
							</td>
							<td>
								<div class="form-group row">
									<div class="col-sm-10">
										<textarea name="implementation" rows="8" cols="70"><?php echo e($crud->implementation); ?></textarea>
									</div>
								</div>
							</td>
							<td>
								<div class="form-group row">
									<div class="col-sm-10">
										<textarea name="level" rows="1" cols="10" readonly style="text-align: center; cursor: not-allowed;"><?php echo e($crud->level); ?></textarea>
									</div>
								</div>
							</td>
							<td id="button">
								<div class="form-group row">
									&nbsp;&nbsp;&nbsp;<button id="elimina" type="submit" class="btn btn-primary"><i class="fa fa-pencil fa-lg">&nbsp;&nbsp;&nbsp;</i>Modifica</button>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</form>
		</div>
		<br><br><br><br><br>
	<hr style="border-width: 5px;">
		<br><br><br>
		<p align="center">Per caricare un <u><b>nuovo file</b></u>, utilizzare il seguente form.<br><br> <b>Importante</b>: puoi aggiornare i file già presenti senza aggiungere una nuova voce per lo stesso file. Sarà sufficiente premere <b><u>Carica</u></b> una volta effettuato il primo upload della risorsa.</p>
		<br><br>
		<div class="container">
			<div class="row">
				<form align="center" action="<?php echo e(action('FileController@storeFile',$id)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		            <?php echo e(csrf_field()); ?>

		            <div align="center" class="container">
		                <input type="file" name="file" required>
		                <input id="elimina" type="submit" class="btn btn-input" value="Carica">
		            </div>
		        </form>
		    </div>
		</div>
		<br><br><br>
		<div class="container">
			<table id="tablefile" class="table table-striped" align="center">
				<thead>
					<tr>
						<th>Nome</th>
						<th>Dimensioni(kb)</th>
						<th>Aggiornato il</th>
						<th style="padding-right: 20px;">Azioni</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($link['id_crud']==$crud->id): ?>
					<tr align="center">
						<td id="idfile" style="padding: 20px;"><?php echo e($link['name']); ?></td>
						<td id="idfile" style="padding: 20px;"><?php echo e($link['size']/1024); ?></td>
						<td id="idfile" style="padding: 20px;"><?php echo e($link['updated_at']); ?></td>
						<td>
							<a href="<?php echo e(action('FileController@reUpload',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px; padding-left: 20px;">
								<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-upload fa-lg">&nbsp;&nbsp;&nbsp;</i>Carica</button>
							</a>
							<a href="<?php echo e(action('FileController@getDownload',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
								<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-download fa-lg">&nbsp;&nbsp;&nbsp;</i>Scarica</button>
							</a>
							<a href="<?php echo e(action('FileController@delete',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
								<button id="elimina" class="btn btn-danger" type="submit"><i class="fa fa-trash fa-lg">&nbsp;&nbsp;&nbsp;</i>Elimina</button>
							</a>
						</td>
					</tr>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<br><br><br><br><br>
	<hr style="border-width: 5px;">
		<br><br><br>
		<div class="container">
			<br><br>
			<p align="center">Per aggiungere un <u><b>link ad una risorsa</b></u>, utilizzare il seguente form. <br><br><b>Importante</b>: puoi aggiornare i link già presenti senza aggiungere una nuova voce per lo stesso link. Sarà sufficiente premere <b><u>Modifica</u></b> una volta effettuato il primo upload della risorsa.</p>
			<p align="center"><b>Nota Bene</b>: per risorse con indirizzo "www", inserire il link anteponendovi "http:\\"</p>
			<div class="container">
				<div class="container" align="center">
					<br><br>
					<a href="<?php echo e(action('LinkController@create',$crud['id'])); ?>" class="btn btn-warning" style="padding: 0px; padding-left: 20px;">
						<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-plus fa-lg">&nbsp;&nbsp;&nbsp;</i>Aggiungi</button>
					</a>
				</div>
				<br><br><br>
				<table id="tablefile" class="table table-striped" align="center">
					<thead>
						<tr>
							<th>Nome</th>
							<th>Link</th>
							<th style="padding-right: 20px;">Azioni</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($link['id_crud']==$crud->id): ?>
						<tr align="center">
							<td id="idfile" style="padding: 20px;"><?php echo e($link['name']); ?></td>
							<td id="idfile" style="padding: 20px;"><?php echo e($link['link']); ?></td>
							<td>
								<a href="<?php echo e(action('LinkController@edit',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px; padding-left: 20px;">
									<button id="modifica" class="btn btn-danger" type="submit"><i class="fa fa-pencil fa-lg">&nbsp;&nbsp;&nbsp;</i>Modifica</button>
								</a>
								<a href="<?php echo e(action('LinkController@delete',$link['id'])); ?>" class="btn btn-warning" style="padding: 0px;">
									<button id="elimina" class="btn btn-danger" type="submit"><i class="fa fa-trash fa-lg">&nbsp;&nbsp;&nbsp;</i>Elimina</button>
								</a>
							</td>
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
		<br><br><br><br><br>
		<a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i> Indietro</button>
		</a>
		<br><br><br><br><br><br><br><br><br>
		<?php endif; ?>
		<?php if(Auth::guest()): ?>
			<br><br><br><br>
			<div align="center">
		    <a href="<?php echo e(URL('/')); ?>" class="btn btn-danger">
					<button id="btn_expire" ></button>
				</a>
			</div>
			<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		<?php endif; ?>
	</body>
</html>