<!DOCTYPE html>
<html>

	<body>

		<div>
			<h1>Id 1</h1>
			<div id="foot" role="navigation">
				<div data-jibp="h" data-jiis="uc" id="cljs"></div>
				<span data-jibp="h" data-jiis="ic" id="xjs">
					<div id="navcnt">
						<!-- inserire menu selezione -->

						<?php

							$lev1 = 'M'; $lev2 = 'S'; $id = 1; $id2 = 2; $id3 = 8;

						?>

						<a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-danger">
							<button id="buttonsubmit" class="btn btn-danger" type="submit">Indietro</button>
						</a>
						<a href="<?php echo e(action('CrudsController@getId_2',$id)); ?>" class="btn btn-danger">
							<button id="buttonsubmit" class="btn btn-danger" type="submit">1</button>
						</a>
						<a href="<?php echo e(action('CrudsController@getId_2',$id2)); ?>" class="btn btn-danger">
							<button id="buttonsubmit" class="btn btn-danger" type="submit">2</button>
						</a>
						<a href="<?php echo e(action('CrudsController@getId_2',$id3)); ?>" class="btn btn-danger">
							<button id="buttonsubmit" class="btn btn-danger" type="submit">8</button>
						</a>
					</div>
				</span>
			</div>
		</div>

		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>ID_1</th>
						<th>ID_2</th>
						<th>ID_3</th>
						<th>Descrizione</th>
						<th>Implementazione</th>
						<th>Livello</th>
						<th colspan="2" align="center">Azioni</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td id="id"><?php echo e($post['id_1']); ?></td>
						<td id="id"><?php echo e($post['id_2']); ?></td>
						<td id="id"><?php echo e($post['id_3']); ?></td>
						<td id="desc"><?php echo e($post['description']); ?></td>
						<td id="impl"><?php echo e($post['implementation']); ?></td>
						<td id="lev"><?php echo e($post['level']); ?></td>
						<td>
							<a href="<?php echo e(action('CrudsController@change',$post['id'])); ?>" class="btn btn-warning">
								<button id="modifica" class="btn btn-danger" type="submit">Modifica</button>
							</a>
						</td>
						<td>
							<a href="<?php echo e(action('CrudsController@getIdDetail',$post['id'])); ?>" class="btn btn-warning">
								<button id="elimina" class="btn btn-danger" type="submit">Elimina</button>
							</a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>			

			<br><br><br><br><br>
			
	</body>

	<style type="text/css">
		html, body {
		    background-color: #fff;
		    color: #636b6f;
		    font-family: 'Raleway', sans-serif;
		    font-weight: 100;
		    padding: 30px;
		    margin: 0px;
		}

		tr,td{
			border-top: 1px solid #E7E7E7;
		}

		#id{
			text-align: center;
		}

		#desc{
			width: 350px;
		}

		#impl{
			text-align: justify;
		}

		#lev{
			text-align: center;
		}

		#modifica{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #0076a3;
			background: -webkit-gradient(linear, left top, left bottom, from(#00adee), to(#00749F));
			background: -webkit-linear-gradient(top,  #00adee,  #00749F);
			background: -moz-linear-gradient(top,  #00adee,  #00749F);
			background: -ms-linear-gradient(top,  #00adee,  #00749F);
			background: -o-linear-gradient(top,  #00adee,  #00749F);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		#modifica:hover{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #0076a3;
			background: -webkit-gradient(linear, left top, left bottom, from(#05BBFF), to(#0089BD));
			background: -webkit-linear-gradient(top,  #05BBFF,  #0089BD);
			background: -moz-linear-gradient(top,  #05BBFF,  #0089BD);
			background: -ms-linear-gradient(top,  #05BBFF,  #0089BD);
			background: -o-linear-gradient(top,  #05BBFF,  #0089BD);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		#modifica:active{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #0076a3;
			background: -webkit-gradient(linear, left top, left bottom, from(#00749F), to(#00adee));
			background: -webkit-linear-gradient(top,  #00749F,  #00adee);
			background: -moz-linear-gradient(top,  #00749F,  #00adee);
			background: -ms-linear-gradient(top,  #00749F,  #00adee);
			background: -o-linear-gradient(top,  #00749F,  #00adee);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		#elimina{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #9D0000;
			background: -webkit-gradient(linear, left top, left bottom, from(#E30000), to(#A80000));
			background: -webkit-linear-gradient(top,  #E30000,  #A80000);
			background: -moz-linear-gradient(top,  #E30000,  #A80000);
			background: -ms-linear-gradient(top,  #E30000,  #A80000);
			background: -o-linear-gradient(top,  #E30000,  #A80000);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		#elimina:hover{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #9D0000;
			background: -webkit-gradient(linear, left top, left bottom, from(#FF0101), to(#BB0000));
			background: -webkit-linear-gradient(top,  #EE0000,  #CD0000);
			background: -moz-linear-gradient(top,  #EE0000,  #CD0000);
			background: -ms-linear-gradient(top,  #EE0000,  #CD0000);
			background: -o-linear-gradient(top,  #EE0000,  #CD0000);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		#elimina:active{
			outline: none;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			font: bold 12px Arial, Helvetica, sans-serif;
			color: #fff;
			padding: 10px 10px;
			border: solid 1px #9D0000;
			background: -webkit-gradient(linear, left top, left bottom, from(#A80000), to(#E30000));
			background: -webkit-linear-gradient(top,  #A80000,  #E30000);
			background: -moz-linear-gradient(top,  #A80000,  #E30000);
			background: -ms-linear-gradient(top,  #A80000,  #E30000);
			background: -o-linear-gradient(top,  #A80000,  #E30000);
			-moz-border-radius: 8px;
			-webkit-border-radius: 8px;
			border-radius: 8px;
			-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.5);
			box-shadow: 0 1px 3px rgba(0,0,0,0.5);
		}

		.dropdown .dropbtn {
		    cursor: pointer;
		    float: right;
		    overflow: hidden;
		    font-size: 16px;    
		    border: none;
		    outline: none;
		    color: #777;
		    padding: 14px 16px;
		    background-color: inherit;
		    position: absolute;
		    right: 275px;
		}

		.dropdown-content {
		    display: none;
		    background-color: #E7E7E7;
		    min-width: 160px;
		    z-index: 1;
		}

		.dropdown-content a:hover {
		    background-color: #eee;
		}

		.show {
		    display: block;
		}

	</style>
</html>