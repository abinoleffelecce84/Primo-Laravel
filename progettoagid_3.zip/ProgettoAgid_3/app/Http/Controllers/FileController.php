<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\File;
use App\Link;
use App\Crud;
use PDF;
use Illuminate\Support\Facades\File as LaraFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;

class FileController extends Controller
{

    public function reUpload($id)
    {
        $file = File::find($id);
        return view('crud.reupload',compact('file','id'));
    }

    public function update(Request $request, $id)
    {
        if($request->hasfile('file'))
        {
            $file = File::find($id);
            $filename = $request->file->getClientOriginalName();
            $filesize = $request->file->getClientSize();
            //$file->name = $file_delete;
            $request->file->storeAs('public/upload',$filename);
            $file->name = $filename;
            $file->size = $filesize;
            $file->save();
            return back();
        }
    }

    public function storeFile(request $request, $id)
    {
    	if($request->hasfile('file'))
		{
    		$filename =  $request->file->getClientOriginalName();
    		$filesize =  $request->file->getClientSize();
            $request->file->storeAs('public/upload',$filename);
            $crud = Crud::find($id);
            $filecrud1 = $crud->id;
    		$file = new File;
    		$file->name = $filename;
    		$file->size = $filesize;
            $file->id_crud = $filecrud1;
    		$file->save();
    		return back();
    	}
    }

    public function getDownload($id)
    {
        $files = File::find($id);
        $filename = $files['name'];
        $path = storage_path('app\public/upload/')."".$filename;
        $headers = array(
            'Content-Type: application/odt',
            'Content-Type: application/ods',
            'Content-Type: application/pdf',
        );
        return Response::download($path, $filename, $headers);
    }

    public function getPdf()
    {
        $cruds = Crud::all()->toArray();
        $files2 = File::all()->toArray();
        $links = Link::all()->toArray();
        $pdf = PDF::loadView('crud/pdfview',compact('cruds','files2','links'))->setPaper('a4','landscape')->setWarnings(false);
        return $pdf->download('sicurezza.pdf');
    }

    public function getPdfLevel($level)
    {
        $cruds = Crud::where('level','=',$level)->get();
        $files2 = File::all()->toArray();
        $links = Link::all()->toArray();
        $pdf = PDF::loadView('crud/pdfview',compact('cruds','files2','links'))->setPaper('a4','landscape')->setWarnings(false);
        return $pdf->download('sicurezza'.$level.'.pdf');
    }

    public function delete($id)
    {
        $files = File::find($id);
        /*$filedelete = $files['name'];
        Storage::delete('public/upload/'.$filedelete);*/
        $files->delete();
        return back();
    }

}