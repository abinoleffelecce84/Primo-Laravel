<html>
	
	<head>
		<link href="css/index.css" rel="stylesheet" type="text/css">
	</head>

    <body>
        <h1>Hello, some heroes here</h1>

			<button id="modifica" class="btn btn-danger" type="submit">Modifica</button>
		
    </body>
</html>